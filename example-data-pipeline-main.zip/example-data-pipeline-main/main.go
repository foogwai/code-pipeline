package main

import (
	"github.com/crseat/example-data-pipeline/internal/infrastructure"
)

func main() {
	infrastructure.StartServer()
}
